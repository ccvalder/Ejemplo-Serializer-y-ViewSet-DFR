from django.shortcuts import render

# Create your views here.

from rest_framework import viewsets
from .models import Libro
from .serializers import LibroSerializer

class LibroViewSet(viewsets.ModelViewSet):
    queryset = Libro.objects.all()
    serializer_class = LibroSerializer


    def get_queryset(self):
        """Filtrar libros por año si se especifica"""
        queryset = Libro.objects.all()
        anio = self.request.query_params.get('anio')
        if anio is not None:
            queryset = queryset.filter(anio_publicacion=anio)
        return queryset
    

    def perform_create(self, serializer):
        """Personalizar la creación"""
        serializer.save()