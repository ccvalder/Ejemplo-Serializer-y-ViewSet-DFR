from rest_framework import serializers
from .models import Libro

class LibroSerializer(serializers.ModelSerializer):
    
    edad_libro = serializers.SerializerMethodField()
    
    class Meta:
        model = Libro
        fields = ['id', 'titulo', 'autor', 'anio_publicacion', 'edad_libro']


    def validate_anio_publicacion(self, value):
        if value > 2025:
            raise serializers.ValidationError(
            "El año de publicación no puede ser futuro"
            )
        return value
    

    def validate(self, data):
        if data['autor'] == 'Anónimo' and data['anio_publicacion'] < 1800:
            raise serializers.ValidationError(
                "No puede haber un autor anónimo antes del año 1800"
            )
        return data
        

    def get_edad_libro(self, obj):
        from datetime import datetime
        return datetime.now().year - obj.anio_publicacion
